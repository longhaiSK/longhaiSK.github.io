__version__ = '7.0.4'


if __name__ == '__main__':
    print(__version__)
