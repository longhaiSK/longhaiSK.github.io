"""Import this file to auto register an AVIF plugin for Pillow."""

from .as_plugin import register_avif_opener

register_avif_opener()
