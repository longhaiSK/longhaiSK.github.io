split_cauchy <- function(n,s, sigma1,sigmasum)
{
   x <- rep(0,n);
   for(i in 1:n)
   {  x[i] <- .C("split_cauchy",0,s,sigma1,sigmasum)[[1]]
   }
   x
}
