.First.lib <- function(lib,pkg)
{
   library.dynam("ClassHighOrderInteract",pkg,lib)
   cat("ClassHighOrderInteract loaded\n", 
       "COPY RIGHT (c) Longhai Li\n", 
       "http://www.utstat.toronto.edu/longhai\n",sep="")
}

