int <- function(x) as.integer(x) 
count_ptns <- function(k,o,p)
{  n <- 0
   for(i in 0:o)
     n <- n + choose(p,i)*k^i
   n
}

