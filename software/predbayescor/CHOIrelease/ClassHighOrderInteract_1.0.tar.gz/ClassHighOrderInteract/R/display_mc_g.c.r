read_mc_g <- function(group, ix, mc_file,iter_b,forward,n,quiet)
{  .C("R_read_mc_g",group,as.integer(ix),mc_file,as.integer(iter_b),
      as.integer(forward),as.integer(n),out=rep(0,n),as.integer(quiet))$out
}

read_betas_g <- function(mc_file,ix_g,ix_cls,no_cls,iter_b,forward,n,quiet)
{
   read_mc_g("betas",ix_g*no_cls+ix_cls, mc_file,iter_b,forward,n,quiet)
} 
