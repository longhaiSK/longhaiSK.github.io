predict_interact <- function(test,no_cls,alpha,mc_file,cases_ptns_file,
                             iter_b,forward,iter_n)
{  if(is.vector(test))
       test <- matrix(test,1,length(test))
  
   n <- nrow(test)
   p <- ncol(test) 
   pred_probs <- matrix(
     .C("R_pred_interact",n,p,as.integer(alpha),as.integer(t(test)), 
      as.integer(no_cls),prediction=rep(0,n*no_cls), 
      mc_file,cases_ptns_file, 
      as.integer(iter_b),as.integer(forward),as.integer(iter_n))$prediction,
      n,no_cls,byrow=TRUE)
  y_pred <- apply(pred_probs,1,which.max)
  data.frame(pred_probs=pred_probs,y_pred)
}

evaluate_prediction <- function(y_true,pred_result,file_detail=c())
{  if(is.vector(pred_result))
     stop("There is only a test case. Cannot make evaluation.")
   wrong <- 1*(pred_result[,"y_pred"]!=y_true)
   error.rate <- mean(wrong)
   probs_true <- y_true
   for(i in 1:length(y_true))
      probs_true[i] <- pred_result[i,y_true[i]]
   amll <- mean(-log(probs_true))
   
   if(!is.null(file_detail))
      write.table(data.frame(y_true=y_true,y_pred=pred_result[,"y_pred"],
                       wrong=wrong,probs_at_true=probs_true),row.names=FALSE)
   list(error.rate=error.rate,amll=amll)
}
