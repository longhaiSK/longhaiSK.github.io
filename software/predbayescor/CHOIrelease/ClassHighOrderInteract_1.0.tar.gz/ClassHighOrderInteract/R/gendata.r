############################################################################
gendata_3D <- function(n,p,o=p,k,cutpointadd=0,prob=0.9)
{  cutoff = matrix(cutpointadd+(k+2)/2,n,o,byrow=TRUE)
   x <- matrix(runif(n*p,1,k+1),n,p)
   x_y <- x[,1:o,drop=FALSE] - matrix(cutoff,n,o,byrow=TRUE)
   y <- (runif(n) < ((apply(x_y,1,prod) > 0) * (2*prob-1) + (1-prob)))*1+1
   x <- matrix(as.integer(x),n,p)
   list(X=x,y=y)
}
############################################################################
#mapping an index in vector format to a location in an array
index_to_pos <- function(index, orders)
{
     sum(index*orders) 
}
############################################################################

gen_binseq_logistic <- function
    (n,p,nos_fth=rep(2,p),alpha=1,
     sigmas_order=c(),beta0=0)
{
    orders <- rep(1,p)
    for(i in 2:p){
       orders[i] <- orders[i-1] * (nos_fth[i-1]+1)
    }
    
    if(length(sigmas_order) < p+1)
    {   if(alpha == 1)
           sigmas_order = c(1, rep(0.05,p)/1:p )
	if(alpha == 2)
	   sigmas_order = c(100, rep(10,p)/1:p )
    }
    
    betas <- matrix(0,1,2)
    colnames(betas) <- c("absolute id of pattern","value")

    #generating beta0
    if(!is.na(beta0) || !is.null(beta0))
       betas[1,2] <- beta0
    else{
       if(alpha == 1)
          betas[1,2] <- rcauchy(1,0,sigmas_order[1])
       else
          betas[1,2] <- rnorm(1,0,sqrt(sigmas_order[1]))
    }
    
    get_beta <- function(index)
    {
      pos <- index_to_pos(index,orders)
      
      pos_beta <- (1:nrow(betas))[betas[,1] == pos]
      if( length(pos_beta) == 0 )
      {
        if(alpha == 1)
           betas <<- rbind(betas,
	              c(pos,rcauchy(1,0,sigmas_order[sum(index!=0)+1])))
        if(alpha == 2)
           betas <<- rbind(betas,
	              c(pos,rnorm(1,0,sqrt(sigmas_order[sum(index!=0)+1]))))
	pos_beta <- nrow(betas)	 
      }
      betas[pos_beta,2]
    }
    
    X <- matrix(0, n, p)
    y <- rep(0, n)
    
    for(i in 1:p)
       X[,i] <- sample(1:nos_fth[i],nrow(X),replace = TRUE)
    
    for(i in 1:n)
    {   
        index <- rep(0,p)
        lv <- get_beta(index)
        for(j in 1:p){
            index[j] <- X[i,j]
            lv <- lv + get_beta(index)
        }
	prob <- 1 / ( 1 + exp(-lv) )
	y[i] <- 1 * ( runif(1) < prob ) + 1
    }
        
    list(X=X,y=y,betas=betas)
}

############################################################################
gen_binclass_logistic <- function
    (n,p,nos_fth=rep(2,p),alpha=1,
     sigmas_order=c(),beta0=0)
{
    orders <- rep(1,p)
    for(i in 2:p){
       orders[i] <- orders[i-1] * (nos_fth[i-1]+1)
    }
    
    if(length(sigmas_order)< p + 1)
    {   if(alpha == 1)
           sigmas_order = c(1, rep(0.5,p)/1:p )
	if(alpha == 2)
	   sigmas_order = c(100, rep(10,p)/1:p )
    }
    
    betas <- matrix(0,1,2)
    colnames(betas) <- c("absolute id of pattern","value")
    #generating beta0
    if(!is.na(beta0) || !is.null(beta0))
       betas[1,2] <- beta0
    else{
       if(alpha == 1)
          betas[1,2] <- rcauchy(1,0,sigmas_order[1])
       else
          betas[1,2] <- rnorm(1,0,sqrt(sigmas_order[1]))
    }
    
    get_beta <- function(index)
    {
      pos <- index_to_pos(index,orders)
      
      pos_beta <- (1:nrow(betas))[betas[,1] == pos]
      if( length(pos_beta) == 0 )
      {
        if(alpha == 1)
           betas <<- rbind(betas,
	              c(pos,rcauchy(1,0,sigmas_order[sum(index!=0)+1])))
        if(alpha == 2)
           betas <<- rbind(betas,
	              c(pos,rnorm(1,0,sqrt(sigmas_order[sum(index!=0)+1]))))
	pos_beta <- nrow(betas)	 
      }
      betas[pos_beta,2]
    }
    
    X <- matrix(0, n, p)
    y <- rep(0, n)
    
    for(i in 1:p)
       X[,i] <- sample(1:nos_fth[i],nrow(X),replace = TRUE)
    
    add_beta <- function(index,i)
    {
        if(i < p){
          add_beta(index,i+1)
	  index[i] <- case[i]
	  add_beta(index,i+1)
	}
	else
	{
	   lv <<- lv + get_beta(index)
	   index[i] <- case[i]
	   lv <<- lv + get_beta(index)
	}
    }
    
    for(i in 1:n)
    {   
        index <- rep(0,p)
        lv <- 0	
        case <- X[i,]
	add_beta(index,1)
	
	prob <- 1 / ( 1 + exp(-lv) )
	y[i] <- 1 * ( runif(1) < prob ) + 1
    }
    
    
    list(X=X,y=y,betas=betas)
}


gen_binseq_fraction <- function
  (n,p,betas=c(0,1,1,1,2), cutoff = 0.4
  )
{
    X <- matrix(0, n, p)
    y <- rep(0, n)
    
    for(i in 1:p)
       X[,i] <- sample(0:1,nrow(X),replace = TRUE)
    
    mod <- function(x,r){
       x - floor(x/r) * r
    }
    for(i in 1:n)
    {
        lv <- betas[1]
	for(j in 1:3)
	{
	   
	   lv <- lv + betas[j+1] * (mod(sum(X[i,1:j]),2)==0)
	}
	lv <- lv + betas[5] * (mean(X[i,]) < cutoff)
	prob <- 1 / ( 1 + exp(-lv) )
	y[i] <- 1 * ( runif(1) < prob )
    }
    names(betas) <- c("intercept","1steven","2ndeven","3rdeven","all")
    list(X = X+1, y = y+1,betas=betas)
}

text_to_number <- function(p,file){
   vtext <- scan(file,what="character",quiet=T)
   ctext <- c()
   for(i in 1:length(vtext)){
     ctext <- c(ctext,strsplit(vtext[i],split="")[[1]]," ")
   }

   
   vowl = c(strsplit("aeiou",split="")[[1]],
            strsplit("AEIOU",split="")[[1]])
   cons = c(strsplit("bcdfghjklmnpqrstvwxyz",split="")[[1]],
            strsplit("BCDFGHJKLMNPQRSTVWXYZ",split="")[[1]])
   ntext <- rep(1,length(ctext))	    
   for(i in 1:length(ctext))
   {  if(sum(vowl==ctext[i]))
         ntext[i] <- 2
      else 
         if(sum(cons==ctext[i]))
	    ntext[i] <- 3	 
   }
   
   ntext2 <- numeric(0)
   i <- 1
   while(i < length(ntext) + 1)
   {  
       ntext2 <- c(ntext2,ntext[i])
       i <- i + 1
       if(ntext[i-1] == 1){
         while(i < length(ntext)+1  )
	   if( ntext[i] == 1 )
             i <- i + 1
	   else break
       }       
       
   }
   
   ntext3 <- matrix(0,length(ntext2)-p,p+1)
   for(i in 1:nrow(ntext3))
      ntext3[i,] <- ntext2[i:(i+p)]
  
   list(X=ntext3[,p:1],y=ntext3[,p+1])
}
