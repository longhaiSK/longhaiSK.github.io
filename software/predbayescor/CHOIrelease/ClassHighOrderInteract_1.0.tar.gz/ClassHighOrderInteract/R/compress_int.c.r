#this is a R wrapper function that calls C function "R_compress_interact" to 
#find the compressed representation of the parameters for interactions
# Arguments:
# features     the data. The rows are observation, 
#              and the columns are features
# nos_fth      a vector indicating the number of possibilities of 
#              features
# depth        the deepest order of interactions
# patterns.rda the filename which saves output "Values"

# Values:
# starts_cases  a vector containing the starting index in "values_cases" 
#               of indice of cases for each group
# values_cases  a vector of all indice of cases in all groups in order
# starts_ptns   a vector containing the starting index in "values_ptns"
#               of indice of patterns for each group
# values_ptns   a vectors of all indice of patterns in all groups in order

compress_interact  <- function(features,nos_fth=c(),depth,no_cases_ign,
                               out_file="patterns.log",quiet=1,do_comp=1)
{  
   if(length(nos_fth)==0) 
      for(i in 1:ncol(features))
         nos_fth[i] = max(features[,i])
   
   if(depth > 0)
     .C("R_compress_interact", nrow(features), ncol(features),
        as.integer(t(features)),as.integer(nos_fth), as.integer(depth),
        as.integer(no_cases_ign), out_file,as.integer(quiet),
	as.integer(do_comp)) -> tmp
   else print("Depth must > 0")
}

display_compress_interact <- function(files, gids=c()){
    
    gids <- as.integer(gids)
    info <- integer(5)
    if(file.exists(files))
       .C("R_display_compress_interact",files,length(gids),gids,
          info)[[4]]
    else 
       cat("File", files, "does not exist","\n")
}
