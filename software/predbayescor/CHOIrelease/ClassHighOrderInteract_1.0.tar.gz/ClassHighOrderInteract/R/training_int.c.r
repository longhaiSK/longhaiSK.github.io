#y_tr is assumed to be coded by 1,2,...,no_cls
training_interact <- function(
    mc_file,cases_ptns_file,
    y_tr,no_cls,alpha,
    a_sigmas,b_sigmas,sigmas,
    iters_mc,iters_bt,iters_hp,
    w_ss,w_hp,m_ss,m_hp)
{
  y_tr <- as.integer(y_tr-1);
  no_cls <- as.integer(no_cls);
  iters_mc <- as.integer(iters_mc);
  iters_bt <- as.integer(iters_bt);
  iters_hp <- as.integer(iters_hp);
  m_ss <- as.integer(m_ss);
  m_hp <- as.integer(m_hp);
  alpha <- as.integer(alpha);
  .C("R_training_interact", mc_file,cases_ptns_file,y_tr,no_cls,
     iters_mc,iters_bt,iters_hp,w_ss,w_hp,m_ss,m_hp,alpha,
     a_sigmas, b_sigmas,sigmas) -> tmp
}
