#calculating the absolute correlation between x and y
abs.cor <- function(x,y)
{
    if(sum(abs(x-mean(x)))==0 || sum(abs(y-mean(y)))==0 )
	return(0)
    else
	return(abs(cor(y,x)))
}
#this function selects features from x by the absolate correlation with y
sel_cor <- function(k,x,y)
{  abscors <- apply(x,2,abs.cor,y)
   sort(abscors,decreasing=TRUE,index.return=TRUE)$ix[1:k]
}
