/*************************************************************************/
/*y_tr is assumed to coded by 0,1,...,no_cls-1 */
void R_training_interact
     (char** mc_file,char** cases_ptns_file, int y_tr[], 
      int no_cls[], int iters_mc[],int iters_ss[], int iters_hp[], 
      double w_ss[], double w_hp[], int m_ss[], int m_hp[],
      int alpha[],double a_sigmas[], double b_sigmas[],
      double sigmas[]){
  training_interact
      (mc_file[0],cases_ptns_file[0],y_tr, 
       no_cls[0],iters_mc[0],iters_ss[0],iters_hp[0], 
       w_ss[0],w_hp[0],m_ss[0],m_hp[0],alpha[0],
       a_sigmas, b_sigmas,sigmas);

}
/***************************************************************************/
/*y_tr is assumed to coded by 0,1,...,no_cls-1 */
void training_interact
     (char mc_file[],char cases_ptns_file[], int y_tr[], 
      int no_cls, int iters_mc,int iters_ss, int iters_hp, 
      double w_ss, double w_hp, int m_ss, int m_hp,
      int alpha,double a_sigmas[], double b_sigmas[],
      double sigmas[])
{   srand(time(0));    
    int n,depth,p,no_g;
    int_list* cases_g = gen_int_list(NULL);
    int_list* ptns_g = gen_int_list(NULL);
    int *sigmas_g;
    sigmas_g = load_compress_interact(cases_g,ptns_g,&n,&p,&depth,
                                      cases_ptns_file,1);
    no_g = cases_g -> ll;    
    /*requesting space for markov chaing sampling*/		      
    double betas[no_g][no_cls],widths_g[no_g],lv[n][no_cls],
         log_sum_exp_lv[n],sum_log_likev[1],sum_log_prior_betas[1],
	 log_prior_sigmas[depth+1],sum_log_prior_sigmas[1],log_postv[1]
	 ;
    
    int i_mc, i_ss, i_hp, i_g, i_cls, i_sgm;
    double beta_o,sigma_o,U,z,beta_n,sigma_n,beta_L,beta_R,
          sigma_L,sigma_R,eval_ss,eval_hp;
    long size_each_iter=sizeof(int)+sizeof(double)*(no_g*no_cls+depth+7);
    int J,K;
    FILE *fp_mc;
    int next_iter_mc = 0;
    int cls_begin = 0;
    if(no_cls == 2) cls_begin = 1;
    
    fp_mc = fopen(mc_file,"rb");
    if(fp_mc == NULL){ 
	fp_mc = fopen_chk(mc_file,"wb");  
	/*creating log file */
        fwrite_chk(&no_cls,sizeof(int),1,fp_mc,mc_file);
	fwrite_chk(&no_g,sizeof(int),1,fp_mc,mc_file);
	fwrite_chk(&depth,sizeof(int),1,fp_mc,mc_file);
	fwrite_chk(&(next_iter_mc),sizeof(int),1,fp_mc,mc_file);        
        set_double_array(no_g*no_cls,betas,0);
	fclose(fp_mc);
    }
    else{
        fseek(fp_mc,-size_each_iter,SEEK_END);
        fread_chk(betas,sizeof(double),no_g*no_cls,fp_mc,mc_file);
        fread_chk(sigmas,sizeof(double),depth+1,fp_mc,mc_file);
	fseek(fp_mc,6*sizeof(double),SEEK_CUR);
        fread_chk(&next_iter_mc,sizeof(int),1,fp_mc,mc_file);
	fclose(fp_mc);	
    }
    
    /*initialize the markov chain state*/
    initialize_mc_state(alpha,cls_begin,no_cls,depth,n,no_g, 
       widths_g,sigmas,betas,y_tr,cases_g,a_sigmas,b_sigmas,sigmas_g,
       sum_log_prior_betas,log_prior_sigmas,sum_log_prior_sigmas, 
       log_postv,lv,sum_log_likev,log_sum_exp_lv);  
    /*starting mc updating with slice sampling*/
    i_mc = 0;
    
    while(i_mc ++ < iters_mc) {
       next_iter_mc++;
       eval_ss = 0;
       eval_hp = 0;
       i_ss = 0;
       while(i_ss++ < iters_ss) {
           for(i_g = 0; i_g < no_g; i_g++) {
               for(i_cls = cls_begin; i_cls < no_cls; i_cls++){        
	          beta_o = betas[i_g][i_cls]; 
	          GetRNGstate();
                  z =  log_postv[0] + log(runif(0,1));
                  PutRNGstate();
                  		
	          /* stepping out */
	          GetRNGstate();
	  	U = runif(0,1);
	  	PutRNGstate();
             	beta_R = beta_o - (w_ss) * U;
	          beta_L = beta_R + (w_ss);		
	  	GetRNGstate();
	          U = rn_unif(0,1);
	          PutRNGstate();
          	J = floor((m_ss) * U);
	          K = (m_ss) - J;
                  /*stepping left*/ 
                  /*printf("stepping left\n");*/
                  do{
                     beta_L -= w_ss;
                     update_by_beta(beta_L,beta_o,i_g,i_cls,
                       n,no_cls,lv,log_sum_exp_lv,log_postv,
                       sum_log_prior_betas,sum_log_likev,
	  	     widths_g,y_tr,cases_g,alpha);
                     beta_o = beta_L;
                     J --; 
	  	   eval_ss++;    
                  }  while(log_postv[0] > z & J > 0);
                  /*stepping right*/
                  /*printf("stepping right\n");*/
	          do{ 
	  	   beta_R += w_ss;
                     update_by_beta(beta_R,beta_o,i_g,i_cls,
                         n,no_cls,lv,log_sum_exp_lv,log_postv,
                         sum_log_prior_betas,sum_log_likev,
	  	       widths_g,y_tr,cases_g,alpha);
	  	   beta_o = beta_R; 
                     K --;  
	  	   eval_ss++;                 
                  }  while(log_postv[0] > z & K > 0);		
	  	/*drawing new points*/
	  	/*printf("drawing new points\n");*/
	  	do{  
                     GetRNGstate();
	  	   beta_n = runif(beta_L,beta_R); 
	  	   PutRNGstate();  
	  	   update_by_beta(beta_n,beta_o,i_g,i_cls,
                         n,no_cls,lv,log_sum_exp_lv,log_postv,
                         sum_log_prior_betas,sum_log_likev,
	  	       widths_g,y_tr,cases_g,alpha);
	  	   beta_o = beta_n;
	  	   eval_ss++;
	  	   if(beta_n > betas[i_g][i_cls]) beta_R = beta_n;
	  	   else beta_L = beta_n;		    
	  	}  while(log_postv[0] < z);		
	  	betas[i_g][i_cls] = beta_n;		  
	      }    
	   }
           
           /*updating hyperparameters*/ 
           i_hp = 0;
           while(i_hp++ < iters_hp) {
               for(i_sgm = 0; i_sgm < depth+1; i_sgm++){	    	   
 	           sigma_o = sigmas[i_sgm];         
 	           GetRNGstate();
 	           z = log_postv[0] + log(runif(0,1));
 	           PutRNGstate();
                    /* stepping out */		
                    GetRNGstate(); 
 	   	U = runif(0,1);
 	   	PutRNGstate();
               	sigma_R = sigma_o - (w_hp) * U;
 	           sigma_L = sigma_R + (w_hp);
 	           GetRNGstate();
 	   	U = runif(0,1);
 	   	PutRNGstate();
            	J = floor((m_hp) * U);
 	           K = (m_hp)-J;
                    /*stepping left*/ 
                    
                    do{
                       sigma_L -= w_hp;
 	   	   if(sigma_L > 0 ){
                           update_by_sigma(sigma_L,sigma_o,i_sgm,
 	   	        widths_g,no_cls,no_g,depth,sigmas_g,
 	   		sum_log_likev,sum_log_prior_betas,
 	   		log_prior_sigmas,sum_log_prior_sigmas, 
                            log_postv,a_sigmas,b_sigmas,betas,alpha,
 	   		cls_begin);			   
                            sigma_o = sigma_L;
 	   		J --; 
            	        eval_hp ++;			
 	   	   }		                     
                    } while (log_postv[0] > z & J > 0 & sigma_L > 0);
                    /*steping right*/
                    
 	           do{
                       sigma_R += w_hp;
                       update_by_sigma(sigma_R,sigma_o,i_sgm,
 	   	        widths_g,no_cls,no_g,depth,sigmas_g,
 	   		sum_log_likev,sum_log_prior_betas,
 	   		log_prior_sigmas,sum_log_prior_sigmas, 
                            log_postv,a_sigmas,b_sigmas,betas,alpha,
 	   		cls_begin);		   	   
                       sigma_o = sigma_R;
                       K --; 
 	   	   eval_hp ++; 
                    } while (log_postv[0] > z & K > 0);  
 	   	/*drawing new points*/
 	   	
 	   	do{ 
                    GetRNGstate();
 	   	    sigma_n = rn_unif(sigma_L,sigma_R);
 	   	    PutRNGstate();
 	   	    if(sigma_n > 0){		    
 	   	       update_by_sigma(sigma_n,sigma_o,i_sgm,
 	   	        widths_g,no_cls,no_g,depth,sigmas_g,
 	   		sum_log_likev,sum_log_prior_betas,
 	   		log_prior_sigmas,sum_log_prior_sigmas, 
                            log_postv,a_sigmas,b_sigmas,betas,alpha,
 	   		cls_begin);		   	    
 	   	        sigma_o = sigma_n;
 	   		eval_hp ++;
 	   	    }		    
 	   	    if(sigma_n > sigmas[i_sgm]) sigma_R = sigma_n;
 	   	    else sigma_L = sigma_n;		    	    
 	   	} while (log_postv[0] < z || sigma_n <= 0);		
 	   	sigmas[i_sgm] = sigma_n;		
               }
           }  
       }      

       /*write markov chain state to a file*/
       eval_ss /= (no_cls - cls_begin)*no_g*iters_ss;
       eval_hp /= (depth+1)*iters_hp;   
       fp_mc = fopen_chk(mc_file,"ab");    
       fwrite_chk(betas,sizeof(double),no_g * no_cls,fp_mc,mc_file);
       fwrite_chk(sigmas,sizeof(double), depth + 1,fp_mc,mc_file);
       fwrite_chk(sum_log_likev,sizeof(double),1,fp_mc,mc_file);
       fwrite_chk(sum_log_prior_betas,sizeof(double),1,fp_mc,mc_file);
       fwrite_chk(sum_log_prior_sigmas,sizeof(double),1,fp_mc,mc_file);
       fwrite_chk(log_postv,sizeof(double),1,fp_mc,mc_file);
       fwrite_chk(&eval_ss, sizeof(double),1,fp_mc,mc_file);
       fwrite_chk(&eval_hp, sizeof(double),1,fp_mc,mc_file);
       fwrite_chk(&next_iter_mc,sizeof(int),1,fp_mc,mc_file);
       fclose(fp_mc);       
    }
     
    printf("%d iterations MC exist in file %s\n",next_iter_mc,mc_file);        
}  
/***************************************************************************/
int_vec* find_cases_gid(int_list *cases_g, int gid){
    
    int_node *node;
    node = cases_g->next;
    if( gid >= cases_g -> ll){
       printf("You are searching a node not existing");
       exit(1);
    }
    int id_node = 0;    
    while(id_node++ < gid & node != 0){        
	node = node -> next;	
    }
    return(node->value);
}

/****************************************************************************/
/* NOTE: this function assumes that the response, y_tr, is 
  coded by 0,...,no_cls - 1  */
void update_by_beta(double beta_n,double beta_o,int i_g,int i_cls,
                    int n,int no_cls,double lv[][no_cls],
		    double log_sum_exp_lv[],double log_postv[], 
		    double sum_log_prior_betas[], 
		    double sum_log_likev[],
		    double widths_g[],int y_tr[], 
		    int_list* cases_g,int alpha){    
    int i,i_case;
    double lv_new,log_likev_new,log_sum_exp_lv_new,diff;
    int_vec *cases;
    /*printf("old beta %f\n",beta_o);
    printf("new beta %f\n",beta_n);*/
    
    cases = find_cases_gid(cases_g, i_g);
    log_postv[0] -= sum_log_likev[0];
    
    for(i = 0; i < cases->lv; i++){
       i_case = cases->v[i];
       lv_new = lv[i_case][i_cls] - beta_o + beta_n;
       diff = lv_new - lv[i_case][i_cls];
       
       lv[i_case][i_cls] = lv_new;
       if(i_cls == y_tr[i_case]){          
	  sum_log_likev[0] += diff;
       }
       /*printf("sumloglikev %f\n",sum_log_likev[0]);
         */
       log_sum_exp_lv_new = log_sum_exp(no_cls,&lv[i_case][0]);
       diff = log_sum_exp_lv_new - log_sum_exp_lv[i_case];       
       log_sum_exp_lv[i_case] = log_sum_exp_lv_new;  
       sum_log_likev[0] -= diff;		
       /*printf("sumloglikev %f\n",sum_log_likev[0]);
         */
    }
    log_postv[0] += sum_log_likev[0];
        
    if(alpha == 1)
        diff = dcauchy(beta_n,0,widths_g[i_g],1) 
       	      - dcauchy(beta_o,0,widths_g[i_g],1); 	                   
    if(alpha == 2)
        diff = dnorm(beta_n,0,sqrt(widths_g[i_g]),1) 
	      - dnorm(beta_o,0,sqrt(widths_g[i_g]),1);
    sum_log_prior_betas[0] += diff;
   
    log_postv[0] += diff;
    
}
/***************************************************************************/

void update_by_sigma
     (double sigma_n,double sigma_o,int i_sgm,double widths_g[],
      int no_cls,int no_g,int depth,int sigmas_g[][depth+1],
      double *sum_log_likev, double *sum_log_prior_betas, 
      double log_prior_sigmas[],double sum_log_prior_sigmas[],
      double *log_postv,double a_sigmas[],double b_sigmas[], 
      double betas[][no_cls],int alpha,int cls_begin
     )
{
    int i_g, i_cls;
    double old_width; 
   
    log_prior_sigmas[i_sgm] = 
            dgamma(1/sigma_n,a_sigmas[i_sgm]/2,
             2/(a_sigmas[i_sgm]*b_sigmas[i_sgm]),1)- 
	     2 * log(sigma_n);
    sum_log_prior_sigmas[0] = sum_double(depth+1,log_prior_sigmas);    
    
    for(i_g = 0; i_g < no_g; i_g++){
       if(sigmas_g[i_g][i_sgm] > 0){
         old_width = widths_g[i_g];
	 /*printf("old sigma %f old width %f\n",sigma_o,widths_g[i_g]);*/
         widths_g[i_g] += sigmas_g[i_g][i_sgm] * (sigma_n - sigma_o);
	 /*printf("new sigma %f new width %f\n",sigma_n,widths_g[i_g]);*/
	 if(alpha == 1){
	   for(i_cls = cls_begin; i_cls < no_cls; i_cls++)
              sum_log_prior_betas[0] += 
	           dcauchy(betas[i_g][i_cls],0,widths_g[i_g],1) 
	            - dcauchy(betas[i_g][i_cls],0,old_width,1);
	 }
	 if(alpha == 2){
	   for(i_cls = cls_begin; i_cls < no_cls; i_cls++)
              sum_log_prior_betas[0] += 
	         dnorm(betas[i_g][i_cls],0,R_pow(widths_g[i_g],0.5),1) 
		  - dnorm(betas[i_g][i_cls],0,R_pow(old_width,0.5),1);	 
         }
	
      }
   }   
   log_postv[0] = sum_log_likev[0] + sum_log_prior_betas[0] + 
                  sum_log_prior_sigmas[0];       
}

/**************************************************************************/

void initialize_mc_state
     (int alpha, int cls_begin,int no_cls,int depth,int n, 
      int no_g, double widths_g[], double sigmas[],
      double betas[no_g][no_cls], double y_tr[],
      int_list* cases_g,
      double a_sigmas[],double b_sigmas[],
      int sigmas_g[][depth+1], 
      double sum_log_prior_betas[], 
      double log_prior_sigmas[],
      double sum_log_prior_sigmas[], 
      double log_postv[], 
      double lv[][no_cls+1],
      double sum_log_likev[],
      double log_sum_exp_lv[]
    ){
    int i_sgm,i_cls,i_g;
    sum_log_prior_betas[0] = 0;
    
    set_double_array(no_g,widths_g,0);
    for(i_g = 0; i_g < no_g; i_g++){
       for(i_sgm = 0; i_sgm < depth + 1; i_sgm ++){       
         if(sigmas_g[i_g][i_sgm] > 0)
           widths_g[i_g] += sigmas_g[i_g][i_sgm] * sigmas[i_sgm];   
       }
    }         
    for(i_g = 0; i_g < no_g; i_g++){
      if(alpha == 1)
         sum_log_prior_betas[0] += 
	    (no_cls-cls_begin)*dcauchy(0,0,widths_g[i_g],1);
      if(alpha == 2)
         sum_log_prior_betas[0] += 
	    (no_cls-cls_begin)*dnorm(0,0,R_pow(widths_g[i_g],0.5),1);      
    }     
    for(i_sgm = 0; i_sgm < depth + 1; i_sgm++)
        log_prior_sigmas[i_sgm] = 
	   dgamma(1/sigmas[i_sgm],a_sigmas[i_sgm]/2,
	          2/(a_sigmas[i_sgm]*b_sigmas[i_sgm]),1) 
		  -  2 * log(sigmas[i_sgm]); 
    sum_log_prior_sigmas[0] = sum_double(depth+1,log_prior_sigmas);    
    set_double_array(n*no_cls,lv,0.0);
    set_double_array(n,log_sum_exp_lv, log(no_cls));
    sum_log_likev[0] = - n * log_sum_exp_lv[0];
    log_postv[0] = sum_log_likev[0]+ sum_log_prior_sigmas[0] +
                   sum_log_prior_betas[0];
    for(i_g = 0; i_g < no_g; i_g ++)
      for(i_cls = cls_begin; i_cls < no_cls; i_cls ++)
         update_by_beta(betas[i_g][i_cls],0.0,i_g,i_cls,
            n,no_cls,lv,log_sum_exp_lv,log_postv,
            sum_log_prior_betas,sum_log_likev,widths_g,y_tr, 
	    cases_g,alpha);  
}    













































