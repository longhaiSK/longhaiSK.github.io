void R_read_mc_g(char **group, int *ix, char **mc_file, int *iter_b,
                int *forward, int *n, double out[],int *quiet);
		
void read_mc_g
   (char* group, int ix, char *mc_file, int iter_b, int forward, int n,
    double out[],int quiet);
