int* load_compress_interact(int_list* cases_g, int_list* ptns_g,
    int* P_n, int* P_p, int* P_depth, char* file, int quiet);
    
void R_display_compress_interact(char** files, int* no_show, int* gids,
                                 int info[5]);
