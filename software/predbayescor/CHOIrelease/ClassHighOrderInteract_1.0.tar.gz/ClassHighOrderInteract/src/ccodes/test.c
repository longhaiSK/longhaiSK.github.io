#include "Rmath.h"
void test(int* b, int* c,double a[*b][*c])
{   int i,j;
     for(i=0;i < *b;i++)
       for(j=0;j < *c; j++)
         a[i][j] = i*j;     
}
