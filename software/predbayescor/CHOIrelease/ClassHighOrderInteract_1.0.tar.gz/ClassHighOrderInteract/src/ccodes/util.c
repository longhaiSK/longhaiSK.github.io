
double find_double_max(int la,double a[]){
    int i;
    int m = a[0];
    for(i = 1; i < la; i++){
       if(a[i] > m) m = a[i];
    }
    return(m);
}

/***********************************************************************/
double sum_double(int len,double A[len])
{  int i; double out=0;
   for(i = 0; i < len; i++) out += A[i];
   return(out);  
} 
/***********************************************************************/

int sum_int(int len,int A[len])
{  int i, out=0;
   for(i = 0; i < len; i++) out += A[i];
   return(out);  
} 
/***********************************************************************/
double avg_double(int len,double A[len])
{  return(sum_double(len,A)/len);  
} 

/***********************************************************************/
double log_sum_exp(int la, double a[])
{  int i;
   double m,out=0;
   m = find_double_max(la,a);
   for(i = 0; i < la; i++){
      out += exp(a[i] - m);
   }
   out = log(out) + m;
   return(out);
}

/***********************************************************************/
void subtract_double_array(int la, double a[], double value)
{  
    int i;
    for(i = 0; i < la; i++)
       a[i] -= value;
}
/***********************************************************************/

void norm_log_array(int la, double a[])
{   
   subtract_double_array(la, a, log_sum_exp(la,a));
}
/***********************************************************************/

/*loga must greater than logb*/
double log_diff_exp(double loga, double logb){
   double m;
   m = loga;
   return(log(exp(loga-m) - exp(logb-m)) + m);
}
/***********************************************************************/

double log_add_exp(double loga, double logb){
   double m;
   if(loga > logb) m = loga;
   else m = logb;
   return(log(exp(loga-m) + exp(logb-m)) + m);
}
/***********************************************************************/
double log_minus_add_exp(double logs,double loga, double logb){
   printf("logs %f loga %f logb %f\n",logs,loga,logb);
   if(loga > logs) {
     exit(1);
   }
   return(logs+log(1.0-exp(loga-logs)+exp(logb-logs)));
}

/***********************************************************************/

void set_double_array(int la, double a[], double value){
   int i;
   for(i = 0; i < la; i++)
      a[i] = value;
    
}
/***********************************************************************/

/* a wrapper function that calls fwrite and does checking */
size_t fwrite_chk
(const void *buffer, size_t num_bytes, size_t count, 
 FILE *fp, char file[]){
   if(fwrite(buffer,num_bytes,count,fp) != count){
      printf("error in writing to file %s\n", file);
      exit(1);
   }
   
}
/***********************************************************************/

size_t fread_chk
(void *buffer, size_t num_bytes, size_t count, 
 FILE *fp, char file[])
{
   if(fread(buffer,num_bytes,count,fp) != count){
      printf("error in reading from file %s\n", file);
      exit(1);
   }
   
}
/***********************************************************************/

FILE *fopen_chk(char file[],const char *mode){
    FILE *fp;
    fp = fopen(file,mode);
    if(fp == NULL){
       printf("cannot open file %s\n", file);
       exit(1);
    }
    return(fp);
}
/***********************************************************************/

double rn_unif(double a, double b){
   return(a + (rand()+1.0)/(RAND_MAX + 2.0) * (b-a) );
}
/***********************************************************************/

void copy_double_array(int la,double *a1, double *a2){
    int i;
    for(i = 0; i < la; i++)
       a1[i] = a2[i];
}
