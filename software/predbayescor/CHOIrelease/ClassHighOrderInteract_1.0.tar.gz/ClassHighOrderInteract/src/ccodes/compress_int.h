/*******************************************************************************************/
int is_unique(int n,int p,int features[n][p],int_vec* sub_cases,int id_fth);


int_vec* take_cases(int_vec* m_cases,int n,int p,int features[n][p],
                    int id_fth,int value);

void trim_ptns(int_list *cases_g, int_list_list *ptns_g);


int_vec* seq(int start,int end);




void diverge(int n, int p,int features[n][p], 
            int_vec* m_cases,int_vec* m_fths,int* nos_fth, 
	    int_list* cases_g, int_list_list* ptns_g, int depth, 
	    int* m_ptn, int_vec* NOs_class, int no_cases_ign,
	    int do_comp);
             
 
double calc_entropy(int_vec* NOs_class, int N);	     

double_vec* entr_sub_sub(int n, int p, int features[n][p], 
                      int_vec* sub_cases,int_vec* sub_fths, 
		      int_vec* NOs_class);	     
void R_compress_interact(int *R_n,int *R_p, int features[*R_n][*R_p], 
                        int *R_nos_fth,int *R_depth,int *R_no_cases_ign,
			char** files, int* R_quiet,
	                int* do_comp);
			
void compress_interact(int n, int p, int features[n][p],int* nos_fth,
                      int depth, int no_cases_ign, char* file, int quiet,
	              int do_comp);

void find_sigmas_g(int_list_list* ptns_g,int depth,int p,
                  int sigmas_g[][depth+1]);

void add_sigmas_patterns(int id_g,int no_g, int depth, int p, 
                        int sigmas_g[][depth+1], 
			int pattern[][p+1]) ;
