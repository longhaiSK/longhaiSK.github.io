#include <R.h>
#include <Rmath.h>
#include <math.h>
/***********************************************************************/
void findmax(double* a, int* I,int* J,int* a_nr, int* a_nc, double* out)
{
    int i, one=1,negone=-1,zero=0; 
    if(!( *I <= *a_nr) || !(*J <= *a_nc))
       error("The index in findmax out of bound");
    if( *J >= 0 )
    {  *out = *(a+(*J));
    
       for(i=1; i < *a_nr; i++)
       {
	  if(*(a+ (*a_nc)*i + (*J)) > *out) *out =  *(a+ (*a_nc)*i+(*J));     
       }
    }
    if( *I >= 0 ) 
        findmax(a+(*I),&negone,&zero,a_nc,&one,out); 
}

/***********************************************************************/
/* this function calculates the log_sum_exp of a column or a row
 of a matrix */
void log_sum_exp(double* a, int* I, int* J, int* a_nr, int* a_nc, 
                 double* out)
{
   int i,one=1,negone=-1,zero=0;
   double sum_exp_sub=0;
   double a_max=0;
   
   if(!( *I <= *a_nr) || !(*J <= *a_nc))
       error("The index in log_sum_exp out of bound");
       
   findmax(a, I, J, a_nr, a_nc, &a_max);
   if( *J >= 0)
   {    
     for(i = 0;i < *a_nr; i++)
     {   sum_exp_sub += exp(*(a + (*a_nc) * i + *J) - a_max);
     }
   	*out = log(sum_exp_sub) + a_max;
   }
   if( *I >= 0)
       log_sum_exp(a+(*I * (*a_nc)), &negone, &zero, a_nc, &one, out);
}

/***********************************************************************/
/* ids_response must be coded from 0 */
void log_like_lv(double *log_likev, int *ids_response, 
                 double *lv, int *lv_nr, int *lv_nc)
{   int i,negone=-1;
    double m;	
    for(i=0; i < *lv_nr; i++)
    {  
	 log_sum_exp(lv,&i,&negone,lv_nr,lv_nc,&m);
	 *(log_likev + i) = *(lv+(*lv_nc)*i + *(ids_response + i) ) - m;	 	   	                     	   	        
    }    
}
/***********************************************************************/
void log_post(double new_beta,double old_beta,int id_beta, int id_cls,
              double alpha, int no_trcases,int no_betas,int no_cls,
	      double widths_betas[no_betas],
	      int patterns[no_trcases][no_betas],int ids_response[no_trcases], 
              double lv[no_trcases][no_cls],double log_likev[no_trcases],
              double* log_postv_sigmas, double* log_postv, 
	      double* sum_log_likev)
{   int i, one=1;
    for(i = 0; i < no_trcases; i++)
    {   if(patterns[i][id_beta]==1)
        {    *sum_log_likev -= log_likev[i];
	     lv[i][id_cls] += (new_beta - old_beta);	     
	     log_like_lv(&log_likev[i],&ids_response[i],&lv[i][0], 
	                 &one,&no_cls);
	     *sum_log_likev += log_likev[i] ;	            
        }
    }	
    if(alpha==1)
       *log_postv_sigmas += (dcauchy(new_beta,0,widths_betas[id_beta],1) 
       			   - dcauchy(old_beta,0,widths_betas[id_beta],1)); 	                   
    else 
       *log_postv_sigmas += (dnorm(new_beta,0,widths_betas[id_beta],1) - 
	                     dnorm(old_beta,0,widths_betas[id_beta],1));	
    *log_postv = (*log_postv_sigmas) + (*sum_log_likev);    	
}
/***********************************************************************/
void eval_width(int no_levels, int no_betas, int info_betas[no_betas][2], 
                double widths_betas[no_betas],double sigmas[no_levels], 
                double alpha) 
{    int i,j,k;
     double widths[no_levels][no_levels];
     for(i = 0; i < no_levels; i++)
       for(j = i; j < no_levels; j++)
       {   widths[i][j] = 0;
           for(k = i; k <= j; k++)
              widths[i][j] += pow(sigmas[k],alpha);
           widths[i][j] = pow(widths[i][j],1/alpha);    
       }
     for(i = 0; i< no_betas; i++)
        widths_betas[i] = widths[info_betas[i][0]][info_betas[i][1]];
}
/***********************************************************************/
double bigger(double a, double b)
{   if(a > b) return(a); else return(b);
}
/***********************************************************************/
void eval_bound(double x, double ratio_unif, double range[2], 
                double out[2])
{  double len = ratio_unif * (range[1]-range[0]);
   out[0] = bigger(x-len,range[0]);
   out[1] = - bigger( -x - len, - range[1]);
}

/***********************************************************************/
double sum_betas_pt(int no_betas, double *betas, int *patterns)
{  double out=0;
   int i;
   for(i=0; i < no_betas; i++) 
   {  if(patterns[i]==1) out += betas[i];
   }
   return(out);
}
/***********************************************************************/
void training_c(double *alpha, double *alpha_sigmas,int *response_tr, 
                int *no_levels,int *no_cls,int *no_betas,int *no_trcases,
		int info_betas[*no_betas][2], 
		double range_sigmas[*no_levels][2], 
		int *beta_is_in_tr,int patterns_tr[*no_trcases][*no_betas],
		int *iters_mc, int *mult_mc, double *m_ss, double *w_ss, 
		int *mult_sigmas,double *ratio_unif,int *initial_size, 
	double betas_ch[*no_cls][*initial_size+*iters_mc][*no_betas],
		double sigmas_ch[*initial_size+*iters_mc][*no_levels],
		int *print_check, double *aml,int *no_btr)		
{   int k, cls_update_begin=0, id_case,id_cls, id_beta,id_sigma,id_rep_sigma,
        J,K,id_cls2,id_beta2,id_mult_mc; 
    double z,beta0_L,beta0_R,beta0_new,beta0_old,U,beta0, 
           sp_widths_betas[*no_betas],
           sp_widths_betas_new[*no_betas],
           *widths_betas=&sp_widths_betas[0],
           *widths_betas_new=&sp_widths_betas_new[0],
           *widths_betas_tmp,
	   sp_range_unif[*no_levels][2],
	   sp_range_unif_new[*no_levels][2],
	   (*range_unif)[2]=&sp_range_unif[0], 
	   (*range_unif_new)[2]=&sp_range_unif_new[0],
	   (*range_unif_tmp)[2],
           log_postv=0,log_postv_sigmas=0,log_postv_sigmas_new=0,
	   log_prop=0,log_prop_new=0,sigmas_new[*no_levels], 
	   lv[*no_trcases][*no_cls],log_likev[*no_trcases],sum_log_likev,
	   avg_stepouts,avg_draws,no_stepouts=0,no_draws=0,iters=0
	   ;
    
    if(*no_cls==2) cls_update_begin = 1;
    /*the sigmas for intercept is fixed to the initial value */
    sigmas_new[0]=sigmas_ch[*initial_size-1][0]; 
    /*calculating the log proposal in M-H sampling */   
    for(id_sigma=1; id_sigma < *no_levels; id_sigma++)
    {  eval_bound(sigmas_ch[*initial_size-1][id_sigma],*ratio_unif,
                   range_sigmas[id_sigma],range_unif[id_sigma]);
       log_prop-=log(range_unif[id_sigma][1]-range_unif[id_sigma][0]);
    }  
    /* calculating the posterior of sigmas */
    for(id_sigma=1; id_sigma < *no_levels; id_sigma++)
    {   log_postv_sigmas -=
         log(sigmas_ch[*initial_size-1][id_sigma]) * (*alpha_sigmas);
    }
    /* calculating the widths of betas */
    eval_width(*no_levels,*no_betas,info_betas,widths_betas,
               sigmas_ch[0],*alpha);  
    /* initializing betas and calculating the log_postv_sigmas */     
    for(id_cls=cls_update_begin;id_cls < *no_cls;id_cls++)
    {  for(id_beta=0;id_beta < *no_betas; id_beta++)
       {  if(*alpha==1)
	  {  GetRNGstate();
	     U = rcauchy(0,widths_betas[id_beta]); PutRNGstate();
	     betas_ch[id_cls][*initial_size-1][id_beta]= U;
	     if(beta_is_in_tr[id_beta]==1)
	       log_postv_sigmas += dcauchy(U,0,widths_betas[id_beta],1);
          }
	  else  
	  {  GetRNGstate();
	     U = rnorm(0,widths_betas[id_beta]); 
	     PutRNGstate();
	     betas_ch[id_cls][*initial_size-1][id_beta]= U;
	     if(beta_is_in_tr[id_beta]==1)
	       log_postv_sigmas += dnorm(U,0,widths_betas[id_beta],1);
          }
       }      
    }
    /*calculating lv and log_likev */
    for(id_case=0; id_case < *no_trcases; id_case++)
    {   for(id_cls=cls_update_begin; id_cls < *no_cls;id_cls++)
       {   lv[id_case][id_cls] = sum_betas_pt(*no_betas,
                     betas_ch[id_cls][*initial_size-1],
		     patterns_tr[id_case]);	
       }
    }
    log_like_lv(&log_likev[0], &response_tr[0],&lv[0][0], 
                no_trcases, no_cls);   
    sum_log_likev = sums(*no_trcases,&log_likev[0]);
    /* starting markov chain sampling */
    for(k = *initial_size; k < (*initial_size + *iters_mc); k++)
    {  /*copying the states from k-1 iteration to k iteration*/
       for(id_cls=cls_update_begin;id_cls < *no_cls;id_cls++)
       {  for(id_beta=0;id_beta < *no_betas; id_beta++)
	  {   if(beta_is_in_tr[id_beta]==1)
	         betas_ch[id_cls][k][id_beta] = 
		  betas_ch[id_cls][k-1][id_beta];
	       else
	       {  /* drawing from the prior */
	         GetRNGstate(); 
	         if(*alpha==1)
		      betas_ch[id_cls][k][id_beta] = 
		       rcauchy(0,widths_betas[id_beta]); 
		 else betas_ch[id_cls][k][id_beta] =
		        rnorm(0,widths_betas[id_beta]); 
		 PutRNGstate(); 
	       }	         
	  }
       }
       /* copying k-1 iteration to k */
       for(id_sigma=0; id_sigma < *no_levels; id_sigma++)
       {  sigmas_ch[k][id_sigma]=sigmas_ch[k-1][id_sigma];
       } 
       /* upstating betas in training cases with slice sampling */
       for(id_mult_mc=0;id_mult_mc < *mult_mc;id_mult_mc++)  
       { log_postv = sum_log_likev + log_postv_sigmas;
         for(id_cls=cls_update_begin;id_cls < *no_cls;id_cls++)
         {  for(id_beta=0;id_beta < *no_betas;id_beta++)
	    {   if(beta_is_in_tr[id_beta]==1)
	        {  iters++;
	           beta0 = betas_ch[id_cls][k][id_beta];		   
		   no_stepouts +=2;
	           /* updating with slice sampling */	         
	           GetRNGstate();z = log_postv - rexp(1);PutRNGstate();
		   /* stepping out */		 
		   GetRNGstate();U = runif(0,1);PutRNGstate();
           	   beta0_L = beta0 - (*w_ss) * U;
	           beta0_R = beta0_L + (*w_ss);
		   GetRNGstate();U = runif(0,1);PutRNGstate();
        	   J = floor((*m_ss) * U);
	           K = (*m_ss)-1-J;
		   beta0_old = beta0;
		   log_post(beta0_L, beta0_old, id_beta, id_cls,
                          *alpha,*no_trcases,*no_betas,*no_cls,widths_betas,
                          patterns_tr,response_tr,lv,log_likev,
                          &log_postv_sigmas,&log_postv,&sum_log_likev);
	           beta0_old = beta0_L;
	           while(log_postv > z && J > 0) 
	           {   beta0_L -= (*w_ss);
		       log_post(beta0_L, beta0_old, id_beta, id_cls,
                          *alpha,*no_trcases,*no_betas,*no_cls,widths_betas,
                          patterns_tr, response_tr,lv,log_likev,
                          &log_postv_sigmas,&log_postv,&sum_log_likev);
	               no_stepouts ++; J --;
		       beta0_old = beta0_L;
	           }
	           log_post(beta0_R, beta0_old, id_beta, id_cls,
                          *alpha,*no_trcases,*no_betas,*no_cls,widths_betas,
                          patterns_tr, response_tr,lv,log_likev,
                          &log_postv_sigmas,&log_postv,&sum_log_likev);        
                   /*Rprintf("stepping out right \n"); */
		   beta0_old = beta0_R;              	         
	           while( log_postv > z && K > 0 ) 	         
	           {  
	              beta0_R += (*w_ss);
	              log_post(beta0_R, beta0_old, id_beta, id_cls,
                          *alpha,*no_trcases,*no_betas,*no_cls,widths_betas,
                          patterns_tr, response_tr,lv,log_likev,
                          &log_postv_sigmas,&log_postv,&sum_log_likev);
         	      no_stepouts++; K --; 
		      beta0_old = beta0_R;
	           }	         				
	           /* drawing point from the slice inside (L,R) 
	                 using shrinkage scheme */
		   for(;;)
         	   {  no_draws ++;
		      GetRNGstate();
	              beta0_new = runif(beta0_L,beta0_R);PutRNGstate();
                      log_post(beta0_new, beta0_old, id_beta, id_cls,
                          *alpha,*no_trcases,*no_betas,*no_cls,widths_betas,
                          patterns_tr, response_tr,lv,log_likev,
                          &log_postv_sigmas,&log_postv,&sum_log_likev);
		      beta0_old = beta0_new;
                      if(log_postv > z) break;
                      if(beta0_new > beta0) beta0_R = beta0_new;
                      else beta0_L = beta0_new;                        
	           }
	           betas_ch[id_cls][k][id_beta] = beta0_new; 
                }
	     }
          }
	  /*updating sigmas*/                         
          for(id_rep_sigma = 0;id_rep_sigma < *mult_sigmas;id_rep_sigma++)
          {    log_prop_new = 0;
               /* generating new values for sigmas */
               for(id_sigma=1; id_sigma < *no_levels;id_sigma++)
               {   GetRNGstate();
	           U = runif(range_unif[id_sigma][0],
		          range_unif[id_sigma][1]);
		   PutRNGstate(); 
	           sigmas_new[id_sigma] = U;
		   eval_bound(U,*ratio_unif,range_sigmas[id_sigma],
		           range_unif_new[id_sigma]);
		   log_prop_new -= log(range_unif_new[id_sigma][1] -
		                    range_unif_new[id_sigma][0]);
	       }
	       eval_width(*no_levels,*no_betas,info_betas,widths_betas_new,
                       sigmas_new,*alpha);                      
               /* calculating log_post_sigma_new */
               log_postv_sigmas_new=0;
               for(id_sigma=1;id_sigma < *no_levels;id_sigma++)
               {   log_postv_sigmas_new -= log(sigmas_new[id_sigma]) *
	                                   (*alpha_sigmas);
               }
	       for(id_cls=cls_update_begin;id_cls < *no_cls;id_cls++)
               {  for(id_beta=0;id_beta < *no_betas; id_beta++)
                  {  if(beta_is_in_tr[id_beta]==1)
                     {   if(*alpha==1)
	                  log_postv_sigmas_new += 
	                    dcauchy(betas_ch[id_cls][k][id_beta],
	                            0,widths_betas_new[id_beta],1);
	                 else  
	                  log_postv_sigmas_new += 
	                    dnorm(betas_ch[id_cls][k][id_beta],
	                            0,widths_betas_new[id_beta],1);
                     }
                  }
               } 
	       GetRNGstate();U = runif(0,1);PutRNGstate();
	       if(log(U) < log_postv_sigmas_new + log_prop_new - 
	                 log_postv_sigmas - log_prop)
	       {   for(id_sigma=1;id_sigma < *no_levels; id_sigma++)
	            sigmas_ch[k][id_sigma]=sigmas_new[id_sigma];
		   log_prop = log_prop_new;
	           log_postv_sigmas = log_postv_sigmas_new;
		   range_unif_tmp = range_unif;
		   range_unif = range_unif_new;
		   range_unif_new = range_unif_tmp;
                   widths_betas_tmp = widths_betas;
		   widths_betas = widths_betas_new;
		   widths_betas_new = widths_betas_tmp;
               }
          }
       }       	          
       /*calculating the average minus log likelihood */       
       aml[k] = - sum_log_likev/(*no_trcases);       
       /* print out infomation on slice sampling and aml*/  
       if(floor(k/(*print_check))*(*print_check)==k)
       {  Rprintf("Iter:%3d,", k);
          avg_draws = no_draws/iters;
          avg_stepouts = no_stepouts / iters;
	  Rprintf("Draws:%1.1f,",avg_draws);
          Rprintf("Steps:%1.1f,",avg_stepouts);
	  Rprintf("SgmB:%1.2f,",sigmas_ch[k][1]);
	  Rprintf("SgmE:%1.2f,",sigmas_ch[k][*no_levels-1]);
          Rprintf("Mlike:%1.2f,",aml[k]); 
          Rprintf("Mprior:%1.2f\n",-log_postv_sigmas/(*no_btr));
          iters = 0; no_stepouts = 0;no_draws = 0;            
       }
   }
} 
/*********************************************************************/
void prob_lv(int len, double lv[len])
{  double m;
   int i,one=1,negone=-1,zero=0;
   log_sum_exp(&lv[0],&zero,&negone,&one,&len,&m);
   for(i=0;i< len;i++)
   {  lv[i] -= m;
      lv[i] = exp(lv[i]);
   }
}
/*********************************************************************/
void multiV(int len, double V[len], double a)
{   int i;
    for(i=0;i < len;i++) V[i] *= a;
}
/*********************************************************************/
void predict_c(int *no_cls,int *iters_mc,int *no_iters_pred,
               int *no_betas,int *no_tscases,
              double betas_ch[*no_cls][*iters_mc][*no_betas], 
	      int iters_pred[*no_iters_pred],
              int patterns_ts[*no_tscases][*no_betas], 
              double prob_pred[*no_tscases][*no_cls])
{   int id_iter,cls_update_begin=0,id_cls,id_case;
    double lv[*no_cls],a=*no_iters_pred;  
    
    if(*no_cls==2) cls_update_begin = 1;
    for(id_iter=0;id_iter < *no_iters_pred;id_iter++)
    {  for(id_case=0;id_case < *no_tscases;id_case++)
       {  for(id_cls=cls_update_begin;id_cls < *no_cls;id_cls++)
          {   lv[id_cls] = sum_betas_pt(*no_betas,
                           betas_ch[id_cls][iters_pred[id_iter]],
		           patterns_ts[id_case]);	
          }	  
	  prob_lv(*no_cls,lv);	  
	  for(id_cls=0; id_cls < *no_cls; id_cls++)
	  {   prob_pred[id_case][id_cls] += lv[id_cls];	  
	  }	  	  
       }   
    }
    multiV((*no_tscases)*(*no_cls),&prob_pred[0][0],1/a);
}
