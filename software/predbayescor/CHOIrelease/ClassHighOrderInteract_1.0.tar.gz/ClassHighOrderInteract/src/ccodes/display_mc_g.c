void R_read_mc_g(char **group, int *ix, char **mc_file, int *iter_b,
                int *forward, int *n, double out[], int *quiet){
    read_mc_g(group[0],ix[0],mc_file[0],iter_b[0],
              forward[0],n[0],out,quiet[0]);

}

void read_mc_g
   (char* group, int ix, char *mc_file, int iter_b, int forward, int n,
    double out[], int quiet){
    FILE *fp_mc;
    int no_iters, no_cls, depth, no_g,known=0;
    long head_in_iter,size_each_iter;
    fp_mc = fopen_chk(mc_file,"rb");
    fseek(fp_mc, - sizeof(int), SEEK_END);
    fread_chk(&no_iters,sizeof(int),1,fp_mc,mc_file);
    printf("%d Iterations of Markov chains existing in file %s\n",
            no_iters,mc_file);
    while(iter_b > no_iters - 1 ){
        printf("Your first iteration index is out of range\n");
	printf("Please input a new one:\n");
	scanf("%d",&iter_b);      
    }
    
    rewind(fp_mc); 
    fread_chk(&no_cls,sizeof(int),1,fp_mc,mc_file);
    fread_chk(&no_g,sizeof(int),1,fp_mc,mc_file);
    fread_chk(&depth,sizeof(int),1,fp_mc,mc_file);
    if(quiet == 0){
      printf("Information in file %s:\n",mc_file);
      printf("Number of classes is %d\n", no_cls);
      printf("Number of groups is %d\n", no_g);
      printf("Number of sigmas is %d\n", depth + 1);
      printf("Number of MC iterations is %d\n", no_iters);
    }
    size_each_iter = sizeof(int) + sizeof(double)*(no_g*no_cls+depth+7);    
        
    while((known++) == 0){
       head_in_iter = sizeof(int);
       if(strcmp(group,"betas") == 0){     
           while(!(ix < no_g*no_cls)){
	       printf("Index should be from %d to %d\n",
	              0,no_g*no_cls-1);
	       printf("Please input new index:\n");
	       scanf("%d",&ix);
	   }
	   head_in_iter += ix * sizeof(double);	       
       }
       else{
           head_in_iter += no_g * no_cls * sizeof(double);
	   if(strcmp(group,"sigmas") == 0){
	      while(!(ix < depth+1)){
	         printf("Index should be from %d to %d\n",
	              0,depth);
	         printf("Please input new index:\n");
	         scanf("%d", &ix);
	       }
	      head_in_iter +=  ix * sizeof(double);
	   }
	   else{
	       head_in_iter += sizeof(double) * (depth+1);
	       if(strcmp(group,"lprobs")==0){
	          while(!(ix < 4)){
	             printf("Index should be from 0 to 3\n");
	             printf("Please input new index:\n");
	             scanf("%d",&ix);
	          }
		  head_in_iter += ix * sizeof(double);
	       }
	       else{ 
	          head_in_iter += sizeof(double) * 4;
		  if(strcmp(group,"evals")==0){
		     while(!(ix < 2)){
	             printf("Index should be from 0 to 1\n");
	             printf("Please input new index:\n");
	             scanf("%d",&ix);
	             }
		     head_in_iter += ix * sizeof(double);
		  }
		     else{
		         printf("Do not know what you want to read\n");
			 printf("Group name should be one from below:\n");
			 printf("******** betas sigmas lprobs evals ********\n");
			 printf("Please select one from above:\n");
			 scanf("%s",group);
		         known = 0;
		     }    
	       }
	     
	  }
      }
   }
   fseek(fp_mc, iter_b * size_each_iter + head_in_iter, SEEK_CUR);   
   int i = 0;
   while(iter_b+i*forward < no_iters & i < n){
       fread_chk(&out[i],sizeof(double),1,fp_mc,mc_file);
       fseek(fp_mc, forward*size_each_iter - sizeof(double),SEEK_CUR);
       i++;
   }	
   
}



		
