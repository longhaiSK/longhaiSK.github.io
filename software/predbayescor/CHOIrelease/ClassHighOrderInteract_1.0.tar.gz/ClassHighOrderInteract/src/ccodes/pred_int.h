void find_widths_g
       (int no_g, int depth, int sigmas_g[no_g][depth+1],
        double sigmas[depth+1],double widths_g[depth+1]);

void find_sigmas_test_interact
        (int_list* ptns_g,int test[],int depth,int p,
	int sigmas_test[][depth+1]);

void add_sigmas_test_interact
       (int no_g,int id_g,int no_ptn,int p,int ptn[][p+1],
        int test[],int depth,int sigmas_test[][depth+1]);

void R_pred_interact
        (int *R_no_test, int *R_p,int *R_alpha,int tests[][R_p[0]],
         int *R_no_cls, double prediction[][*R_no_cls],
         char** mc_files,char** cases_ptns_files, 
         int *R_iter_b,int *R_forward,int *R_iter_n);          
             
void split
      (double *beta_p, double *beta_s, double *width_p, double *width_s,
       int *alpha);        
        
void split_cauchy
     (double *x, double *s, double *sigma1, double *sigmasum, int *debug);        
