
/*******************************************************************************************/
/*this function is to be called by R for displaying the pattern information for specified 
 indice of groups*/
void R_display_compress_interact(char** files, int* no_show, int* gids,
                                 int info[5]){
    /*the blocks of loading compression information from `file'*/
    int n,p,depth,no_g,*sigmas_g,no_ptns;
    int_list *cases_g=gen_int_list(NULL);
    int_list *ptns_g=gen_int_list(NULL);
    if(*no_show > 0){
      sigmas_g = load_compress_interact
                    (cases_g,ptns_g,&n,&p,&depth,files[0],0);
      int_node* ptn_node = ptns_g -> next;
      int_node* cse_node = cases_g -> next;
      int id_g = 0;
      int id_list = 0;
      no_g = cases_g -> ll;
      printf("n: %d, ", n);
      printf("p: %d, ", p);
      printf("order: %d, ", depth);
      printf("No of groups: %d, ", no_g);
      no_ptns = sum_int(cases_g->ll*(depth+1),sigmas_g);
      printf("No of expressed patterns: %d\n",no_ptns);
      while(ptn_node!=NULL & id_g < *no_show){
         if(id_list==gids[id_g]){
            printf("\nInformation of Group %d\n", gids[id_g]);
            printf(
"Pattern(s):(Last column is numbers of fixed nozerors (up) among fixed (down))\n");
            print_int_vec(ptn_node->value,p+1);
            printf("Case(s) Expressed:\n");
            print_int_vec(cse_node->value,n);
	    printf("\n");
            printf(
	"Sigmas:(Starting from order 0, number of patterns in each order)\n");
	    print_int_vec(gen_int_vec(depth+1,
	                  sigmas_g + gids[id_g]*(depth+1)),depth+1);
            id_g ++;
         }
         id_list ++;
         ptn_node = ptn_node -> next;
         cse_node = cse_node -> next;
     }
   }
   else{
       FILE *fp;
       if((fp = fopen(files[0],"rb"))==NULL)
          printf("cannot open file %s\n",files[0]);    
       if(fread(&n,sizeof(int),1,fp)!=1)
          printf("cannot read 'nos_cases'\n");       
       if(fread(&p,sizeof(int),1,fp)!=1)
          printf("cannot read 'p'\n");    
       if(fread(&depth,sizeof(int),1,fp)!=1)
          printf("cannot read 'depth'\n");
       if(fread(&no_g,sizeof(int),1,fp)!=1)
          printf("cannot read 'no_g'\n");
       fseek(fp,- no_g*(depth+1)*sizeof(int),SEEK_END);
       sigmas_g = gen_int_array(no_g*(depth+1));
       fread_chk(sigmas_g,sizeof(int),no_g*(depth+1),fp,files[0]);
       no_ptns = sum_int(no_g*(depth+1),sigmas_g);
       fclose(fp);       
       printf("n: %d, ", n);
       printf("p: %d, ", p);
       printf("order: %d, ", depth);
       printf("No of groups: %d, ", no_g);
       printf("No of expressed patterns: %d\n",no_ptns);
   }
   info[0] = n; info[1] = p; info[2] = depth; info[3] = no_g;
   info[4] = no_ptns;
   
}
/*******************************************************************************************/
/*this function loads the information about compressed parameters from 'file'
to objects defined outside and return the point of matrix containing the `sigmas_g'
information*/
int* load_compress_interact(int_list* cases_g, int_list* ptns_g,
    int* P_n, int* P_p, int* P_depth,  char* file, int quiet){
    FILE *fp;
    int no_ptns;
    if((fp = fopen(file,"rb"))==NULL)
       printf("cannot open file %s\n",file);
    
    if(fread(P_n,sizeof(int),1,fp)!=1)
       printf("cannot read 'nos_cases'\n");   
    
    if(fread(P_p,sizeof(int),1,fp)!=1)
       printf("cannot read 'p'\n");
    
    if(fread(P_depth,sizeof(int),1,fp)!=1)
       printf("cannot read 'depth'\n");
    
    fread_int_list(cases_g,fp);
    fread_int_list(ptns_g,fp);

    
    
    int* sigmas_g = gen_int_array(ptns_g->ll*(*P_depth+1));
    if(fread(sigmas_g, sizeof(int),ptns_g->ll*(*P_depth+1), fp)
      != ptns_g->ll*(*P_depth+1))
       printf("cannot read information of sigmas \n"); 
    fclose(fp);
    return(sigmas_g);
}

