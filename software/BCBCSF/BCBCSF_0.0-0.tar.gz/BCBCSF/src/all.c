# include <math.h>
# include <Rmath.h> 
# include <stdio.h>
# include <R.h>

# include "ccodes/adjfactor.c"
# include "ccodes/pred.c"
