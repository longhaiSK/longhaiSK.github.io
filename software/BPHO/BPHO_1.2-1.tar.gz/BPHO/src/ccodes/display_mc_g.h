void R_read_mc(char **group, int *ix, char **mc_file, int *iter_b,
                int *forward, int *n, double out[]);
		
void read_mc
   (char* group, int ix, char *mc_file, int iter_b, int forward, int n,
    double out[]);
void display_mc(char** mc_files,int out[5]);
