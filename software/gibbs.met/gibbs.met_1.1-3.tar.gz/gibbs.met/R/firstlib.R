.First.lib <- function(lib,pkg)
{
   cat("Naive Gibbs Sampling with Metropolis steps(gibbs.met) loaded\n", 
       "COPYRIGHT 2008 (c) Longhai Li (http://math.usask.ca/~longhai)\n",
        "Type ?begin.gibbs.met for help to this package\n",sep="")

}
