# 		md_trj <- md
#         
#         NDloglike_trj <- NDloglike
#         loglike_trj <- loglike

# 		if (lookleapfrog) ## recording initial values
# 		{
# 			magdeltas_lp <- sqrt (sum (deltas_trj ^ 2) )
# 			loglike_lp <- loglike
# 			logprior_lp <- - sum (md / allsigmas) / 2
# 			log_prob_momt_lp <- log_prob_momt_old
# 		}
