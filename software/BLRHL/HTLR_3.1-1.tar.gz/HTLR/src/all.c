# include <math.h>
# include <Rmath.h>
# include <stdio.h>
# include <R.h>
# include <string.h>

# include "ccodes/vecmat.c"
# include "ccodes/ars.c"
# include "ccodes/gibbs.c"


