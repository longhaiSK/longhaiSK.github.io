.First.lib <- function(lib,pkg)
{
   #library.dynam("predmixcor",pkg,lib)
   cat("predmixcor loaded\n", 
       "COPY RIGHT: Longhai Li\n", 
       "http://math.usask.ca/~longhai\n",
       "Type ?begin.predmixcor for help\n",sep="")
}

